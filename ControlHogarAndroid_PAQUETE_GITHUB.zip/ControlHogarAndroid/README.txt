Control del Hogar

Proyecto Android offline, sin permisos de internet. Datos guardados localmente en el teléfono mediante almacenamiento del navegador WebView.
Para compilar: subir esta carpeta al repositorio GitHub y configurar un workflow que ejecute gradle assembleDebug desde esta carpeta.
La APK debug se genera en app/build/outputs/apk/debug/app-debug.apk.
Exporta CSV para hojas de cálculo y JSON para respaldar/importar los registros.
